import { View, Text, FlatList, TouchableOpacity, Image } from 'react-native'
import React from 'react'
import styles from '../styles/styles'
import { categoryData } from '../../../common/Contant'

export default function Categories() {
  return (
    <View style={styles.category}>
      <Text style={styles.category__text}>Main</Text>
      <Text style={styles.category__text}>Categories</Text>
      <CategoriesList />
    </View>
  )
}

export const CategoriesList = () => {

    renderItem = ({item}) => (
        <TouchableOpacity
            style={styles.category_list}
        >
            <View style={styles.category_list__circle}>
                <Image style={styles.category_list__circle__icon} source={item.icon}/>
            </View>

            <Text style={styles.category_list__text}>{item.name}</Text>
           
        </TouchableOpacity>
    )

    return(
        <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={categoryData}
            renderItem={renderItem}
        />
    )
}