import { Text, View, SafeAreaView } from 'react-native'
import React from 'react'
import AppBar from './component/AppBar'
import Categories from './component/Categories'
import Menu from './component/Menu'
import styles from './styles/styles'

export default HomeScreen = () => {
  return(
    <SafeAreaView style={styles.container}>
      <AppBar />
      <Categories />
      <Menu />
    </SafeAreaView>
  )
}
